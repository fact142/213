import React from 'react';
import './App.css';
import SingerList from "./components/SingerList";
import PostForm from "./components/PostForm.js"
let singer_name;
let singer_description;

class App extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            singers: [],
            id_singer: '',
            singer_name: '',
            singer_description: '',
            };
        this.handleDelete=this.handleDelete.bind(this)
        };

    handleChangeName(e) {
        this.setState( {
            singer_name: e.target.value,
        })
    }
    handleChangeEmail(e) {
        this.setState( {
            singer_description: e.target.value,
        })
    }
    handleChangeId(e) {
        this.setState( {
            id_singer: e.target.value,

        })
    }

    handleSubmit(e) { 
        alert("Клиент добавлен в БД.");
        e.preventDefault();
        try {
            singer_name = this.state.singer_name;
            singer_description = this.state.singer_description;
            const body = {singer_name, singer_description};
            const response = fetch('http://localhost:3141/singer', {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(body)
            });
            console.log(response);  
        } catch (err) {
            console.error(err.message)
        }

    }

    handleSubmit = singer => {
        console.log(singer)
        const response = fetch('http://localhost:3141/singer/',{
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(singer)
        })  
        .then(res => res.text()) 
        .then(res => res)
        this.setState({singers: [...this.state.singers]});
    }

    handleDelete(id) {
        const { singers } = this.state;
    
        this.setState({
            singers: singers.filter((singer) => { 
                return singer.id_singer !== id;
            })
        });
        fetch('http://localhost:3141/singer/' + id, {
                method: 'DELETE',
            })
    }


    handleEdit(e) {
        e.preventDefault();

        try {
            singer_name = this.state.singer_name;
            singer_description = this.state.singer_description;
            const body = {singer_name, singer_description};
            const response = fetch('http://localhost:3141/singer/' + this.state.id_singer, {
                method: 'PUT',
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(body)
            })
                .then(res => res.text()) 
                .then(res => console.log(res))
            console.log(response);
        } catch (err) {
            console.error(err.message)
        }


    }

    callApi(){
        fetch("http://localhost:3141/singer")
            .then((res) => res.json()
            .then((data) => {
                this.setState({singers: data})
            })
            )
            .catch(err => err)
    }
    componentDidMount() {
        this.callApi()
    }

    render(){
        return(
            <fieldset className="container mt-5">
                <h2 className="text-center mt-5">POST Request</h2>
                <br></br>
                <form onSubmit={this.handleSubmit.bind(this)}>
                    <div className="form-control" >
                        <label for="n">Name </label>
                        <input
                            id="n"
                            type="text"
                            className="form-control"
                            singer_name={this.state.singer_name} onChange={this.handleChangeName.bind(this)} />
                        <br></br>
                        <label  for="e">Email </label>
                        <input
                            id="e"
                            type="text"
                            className="form-control"
                            singer_description={this.state.singer_description} onChange={this.handleChangeEmail.bind(this)} />
                        <br></br>
                        <div className="text-right">
                            <button className="btn btn-success">Add</button>
                        </div>
                    </div>

                </form> 
                <PostForm handleSubmit={this.handleSubmit}/>
                <br></br>
                <h2 className="text-center mt-5">PUT Request</h2>
                <br></br>
                <form onSubmit={this.handleEdit.bind(this)}>
                    <div className="form-control">
                        <label htmlFor="id">id </label>
                        <input
                            id="id"
                            type="text"
                            className="form-control"
                            id_singer={this.state.id_singer} onChange={this.handleChangeId.bind(this)}/>
                        <br></br>
                        <label htmlFor="n">Name </label>
                        <input
                            id="n"
                            type="text"
                            className="form-control"
                            singer_name={this.state.singer_name} onChange={this.handleChangeName.bind(this)}/>
                        <br></br>
                        <label htmlFor="e">Email </label>
                        <input
                            id="e"
                            type="text"
                            className="form-control"
                            singer_description={this.state.singer_description} onChange={this.handleChangeEmail.bind(this)}/>
                        <br></br>
                        <div className="text-right">
                            <button className="btn btn-dark">Change</button>
                        </div>
                    </div>
                </form>
                <h2 className="text-center mt-5">Clients List</h2>
                <br></br>
                <SingerList singers={this.state.singers} remove={this.handleDelete}/>
                <br></br>
                <br></br>
                <br></br>


            </fieldset>
        )
    }
}

export default App;